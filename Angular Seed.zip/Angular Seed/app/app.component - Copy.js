"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var AppComponent = (function () {
    function AppComponent() {
        //model
        this.courseName = "Angular 2";
        this.imageUrl = "http://blog.ninja-squad.com/assets/images/ng2-ebook/ng2-logo.png";
        this.isDisabled = true;
        this.isSuccess = false;
        this.courses = ['ReactJS', 'AngularJS', 'PolymerJS'];
    }
    AppComponent.prototype.HandleClick = function () {
        // console.log('U Clicked !');
        this.courseName = "ReactJS";
    };
    AppComponent.prototype.HandleChange = function ($event) {
        // target -> object on which event has fired ! (textbox)
        this.courseName = $event.target.value;
        //console.log($event);
    };
    AppComponent = __decorate([
        core_1.Component({
            selector: 'my-app',
            //    template: `<h1> Hello {{ courseName  }}  ! </h1>
            //            <div  *ngIf="!isDisabled">
            //                        <img src="{{ imageUrl }}" height="100px" width="200px" />
            //                        <img [src]="imageUrl"  height="100px" width="200px" />
            //                        <img bind-src="imageUrl"  height="100px" width="200px" />
            //                        <input type="button" class="btn" [class.btn-success]="!isSuccess"  value="Class applied !" />
            //                    <input type="button" [style.backgroundColor]="isSuccess ? 'green' : 'orange'"   value="Styled button !" />
            //                    <input type="button" class="btn btn-success"  value="Click me !" (click)="HandleClick()" />
            //                    <input type="button" value="Using ngClass Directive !" [ngClass]="{
            //                                        'btn':isDisabled,
            //                                        'btn-success':!isSuccess
            //                                }"  />
            //</div>
            // `,
            //template: `<h1> Hello {{ courseName  }}  ! </h1>
            //                    <course></course>
            //                    <input type="button" [disabled]=isDisabled value="Disabled ?" />
            //                `,
            //templateUrl: '/app/app.component.html',
            //template: `
            //                    <ul>
            //                            <li *ngFor="let c of courses">
            //                                    {{ c }}
            //                            </li>
            //                    </ul>
            //            `,
            template: "<h1> Hello {{ courseName  }}  ! </h1>\n                              Enter CourseName here : <input type=\"text\" [value]=\"courseName\" (input)=\"HandleChange($event)\" /><br/>\n                             <input type=\"text\" [(ngModel)]=\"courseName\" /> <br/>\n                                Is Success ?? : <input type=\"checkbox\" [(ngModel)]=\"isSuccess\" />\n                                <input type=\"button\" class=\"btn\" [class.btn-success]=\"isSuccess\"  value=\"Click me !\" (click)=\"HandleClick()\" />\n\n                    "
        }), 
        __metadata('design:paramtypes', [])
    ], AppComponent);
    return AppComponent;
}());
exports.AppComponent = AppComponent;
//# sourceMappingURL=app.component - Copy.js.map