import {Component} from '@angular/core';
import {CourseComponent} from './course.component';


@Component({
    selector: 'my-app',
    //template: `

    //                `,

    templateUrl:'/app/app.component.html',
    directives: [CourseComponent]
})
export class AppComponent {
    //model
    courses: any[] = [
        { title: 'AngularJS', duration: '3 Days', rating: 4.5, price: 20000 },
        { title: 'ReactJS', duration: '5 Days', rating: 4.5, price: 90000 },
        { title: 'PolymerJS', duration: '2 Days', rating: 4.5, price: 40000 },
        { title: 'BackboneJS', duration: '4 Days', rating: 4.5, price: 80000 }
    ];

    onSubmitForm(form) {

        let newCourse = {
            title: form.controls.title.value,
            price: form.controls.price.value,
            duration: form.controls.duration.value,
            rating: form.controls.rating.value
        }

      
        this.courses.push(newCourse);

    }

   
}