﻿import {Component,Input} from '@angular/core';


@Component({
    selector: 'course',
    templateUrl: '/app/course.component.html',
    inputs: ['courseOffered']
})
export class CourseComponent {
    @Input('courseOffered') actualCourse: any = {  };
}
