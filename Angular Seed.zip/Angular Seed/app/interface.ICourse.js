"use strict";
//# sourceMappingURL=interface.ICourse.js.map